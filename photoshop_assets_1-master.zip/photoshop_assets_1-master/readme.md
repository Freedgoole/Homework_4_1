# Верстка по макету Photoshop
### HTML/CSS
Выполнить верстку карты товара согласно макету представленному ниже. Размеры, цвет, шрифты, размеры шрифтов взять из psd файла.

![](https://raw.githubusercontent.com/luschenko/photoshop_assets_1/master/lenovo.png)
		
